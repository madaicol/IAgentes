

applicacion.controller('portadacontroller',['$scope','toastr',function($scope,toastr){

    // toastr.info('Info','Entraste a portada');
    // $scope.enviarActual=null;

}]);
